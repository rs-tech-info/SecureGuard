package com.secureguard.app.detector;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PermissionInfo;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class AppScanner {

    private final Context context;
    private final PackageManager packageManager;

    // HIGH RISK permissions that fraud/spyware apps use
    private static final List<String> HIGH_RISK_PERMISSIONS = Arrays.asList(
        "android.permission.READ_SMS",
        "android.permission.RECEIVE_SMS",
        "android.permission.SEND_SMS",
        "android.permission.READ_CALL_LOG",
        "android.permission.PROCESS_OUTGOING_CALLS",
        "android.permission.READ_CONTACTS",
        "android.permission.RECORD_AUDIO",
        "android.permission.CAMERA",
        "android.permission.ACCESS_FINE_LOCATION",
        "android.permission.READ_PHONE_STATE",
        "android.permission.GET_ACCOUNTS",
        "android.permission.USE_CREDENTIALS",
        "android.permission.BIND_DEVICE_ADMIN",
        "android.permission.SYSTEM_ALERT_WINDOW",
        "android.permission.WRITE_SETTINGS"
    );

    // Known suspicious package name patterns (scammers use these)
    private static final List<String> SUSPICIOUS_PATTERNS = Arrays.asList(
        "screen.share", "remote.access", "anydesk", "teamviewer",
        "remote.desktop", "screen.record", "keylog", "spy",
        "monitor", "track", "hidden", "stealth", "invisible"
    );

    // Legitimate system packages to whitelist
    private static final List<String> SAFE_PACKAGES = Arrays.asList(
        "com.android", "com.google", "com.samsung", "com.miui",
        "com.oneplus", "com.oppo", "com.vivo", "com.realme",
        "com.qualcomm", "android", "com.secureguard.app"
    );

    public AppScanner(Context context) {
        this.context = context;
        this.packageManager = context.getPackageManager();
    }

    public List<ScannedApp> scanAllApps() {
        List<ScannedApp> riskyApps = new ArrayList<>();
        List<PackageInfo> packages = packageManager.getInstalledPackages(PackageManager.GET_PERMISSIONS);

        for (PackageInfo packageInfo : packages) {
            if (isSafePackage(packageInfo.packageName)) continue;

            ScannedApp scannedApp = analyzeApp(packageInfo);
            if (scannedApp.getRiskLevel() != RiskLevel.SAFE) {
                riskyApps.add(scannedApp);
            }
        }

        // Sort: HIGH risk first
        riskyApps.sort((a, b) -> b.getRiskScore() - a.getRiskScore());
        return riskyApps;
    }

    private ScannedApp analyzeApp(PackageInfo packageInfo) {
        String packageName = packageInfo.packageName;
        String appName = getAppName(packageName);
        List<String> foundRiskyPerms = new ArrayList<>();
        int riskScore = 0;

        // Check permissions
        if (packageInfo.requestedPermissions != null) {
            for (String perm : packageInfo.requestedPermissions) {
                if (HIGH_RISK_PERMISSIONS.contains(perm)) {
                    foundRiskyPerms.add(formatPermission(perm));
                    riskScore += getPermissionWeight(perm);
                }
            }
        }

        // Check suspicious package name
        boolean isSuspiciousName = false;
        String lowerPkg = packageName.toLowerCase();
        for (String pattern : SUSPICIOUS_PATTERNS) {
            if (lowerPkg.contains(pattern)) {
                isSuspiciousName = true;
                riskScore += 40;
                break;
            }
        }

        // Check if NOT from Play Store (sideloaded = more risky)
        boolean isSideloaded = isSideloaded(packageName);
        if (isSideloaded) riskScore += 20;

        // Check if app is hidden / no launcher icon
        boolean isHidden = isHiddenApp(packageInfo);
        if (isHidden) riskScore += 50;

        // Determine threat category
        String threatType = determineThreatType(foundRiskyPerms, isSuspiciousName, isHidden, isSideloaded);

        RiskLevel riskLevel;
        if (riskScore >= 70) riskLevel = RiskLevel.CRITICAL;
        else if (riskScore >= 40) riskLevel = RiskLevel.HIGH;
        else if (riskScore >= 20) riskLevel = RiskLevel.MEDIUM;
        else riskLevel = RiskLevel.SAFE;

        return new ScannedApp(packageName, appName, riskLevel, riskScore,
                foundRiskyPerms, threatType, isHidden, isSideloaded);
    }

    private String determineThreatType(List<String> perms, boolean suspName, boolean hidden, boolean sideloaded) {
        boolean readsSms = perms.stream().anyMatch(p -> p.contains("SMS"));
        boolean readsCall = perms.stream().anyMatch(p -> p.contains("CALL"));
        boolean recordsAudio = perms.stream().anyMatch(p -> p.contains("AUDIO"));

        if (hidden && (readsSms || readsCall)) return "🚨 Possible Spyware / OTP Stealer";
        if (readsSms && readsCall) return "⚠️ Banking Fraud Risk - Reads SMS & Calls";
        if (readsSms) return "⚠️ OTP Interception Risk";
        if (readsCall) return "⚠️ Call Monitoring Risk";
        if (recordsAudio) return "🎙️ Audio Recording Risk";
        if (suspName) return "🔍 Suspicious App Name Pattern";
        if (sideloaded) return "📦 Sideloaded - Unverified Source";
        return "⚠️ Multiple Risky Permissions";
    }

    private int getPermissionWeight(String permission) {
        if (permission.contains("READ_SMS") || permission.contains("RECEIVE_SMS")) return 30;
        if (permission.contains("CALL_LOG") || permission.contains("OUTGOING_CALLS")) return 25;
        if (permission.contains("RECORD_AUDIO")) return 20;
        if (permission.contains("BIND_DEVICE_ADMIN")) return 40;
        if (permission.contains("SYSTEM_ALERT_WINDOW")) return 20;
        if (permission.contains("GET_ACCOUNTS") || permission.contains("USE_CREDENTIALS")) return 25;
        return 10;
    }

    private boolean isSafePackage(String packageName) {
        for (String safe : SAFE_PACKAGES) {
            if (packageName.startsWith(safe)) return true;
        }
        return false;
    }

    private boolean isSideloaded(String packageName) {
        try {
            String installer = packageManager.getInstallerPackageName(packageName);
            return installer == null || (!installer.equals("com.android.vending")
                    && !installer.equals("com.google.android.packageinstaller"));
        } catch (Exception e) {
            return true;
        }
    }

    private boolean isHiddenApp(PackageInfo packageInfo) {
        Intent launchIntent = packageManager.getLaunchIntentForPackage(packageInfo.packageName);
        boolean isSystemApp = (packageInfo.applicationInfo.flags & ApplicationInfo.FLAG_SYSTEM) != 0;
        return launchIntent == null && !isSystemApp;
    }

    private String getAppName(String packageName) {
        try {
            ApplicationInfo ai = packageManager.getApplicationInfo(packageName, 0);
            return packageManager.getApplicationLabel(ai).toString();
        } catch (Exception e) {
            return packageName;
        }
    }

    private String formatPermission(String perm) {
        return perm.replace("android.permission.", "").replace("_", " ");
    }

    // ---- Model class ----
    public static class ScannedApp {
        private final String packageName;
        private final String appName;
        private final RiskLevel riskLevel;
        private final int riskScore;
        private final List<String> riskyPermissions;
        private final String threatType;
        private final boolean isHidden;
        private final boolean isSideloaded;

        public ScannedApp(String packageName, String appName, RiskLevel riskLevel,
                         int riskScore, List<String> riskyPermissions, String threatType,
                         boolean isHidden, boolean isSideloaded) {
            this.packageName = packageName;
            this.appName = appName;
            this.riskLevel = riskLevel;
            this.riskScore = riskScore;
            this.riskyPermissions = riskyPermissions;
            this.threatType = threatType;
            this.isHidden = isHidden;
            this.isSideloaded = isSideloaded;
        }

        public String getPackageName() { return packageName; }
        public String getAppName() { return appName; }
        public RiskLevel getRiskLevel() { return riskLevel; }
        public int getRiskScore() { return riskScore; }
        public List<String> getRiskyPermissions() { return riskyPermissions; }
        public String getThreatType() { return threatType; }
        public boolean isHidden() { return isHidden; }
        public boolean isSideloaded() { return isSideloaded; }
    }

    public enum RiskLevel {
        SAFE, MEDIUM, HIGH, CRITICAL
    }
}
