package com.secureguard.app.detector;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.telephony.TelephonyManager;
import com.secureguard.app.ui.ThreatAlertActivity;
import com.secureguard.app.utils.NotificationHelper;
import com.secureguard.app.utils.SharedPrefManager;
import com.secureguard.app.utils.ThreatLogger;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Pattern;

public class CallReceiver extends BroadcastReceiver {

    // Patterns for suspicious numbers
    private static final Pattern INTERNATIONAL_PREMIUM = Pattern.compile(
        "^\\+(?!91|1|44|61|971)[0-9]{8,}$"  // International non-India/US/UK numbers
    );

    private static final Pattern SPOOFED_NUMBER = Pattern.compile(
        "^0{2,}|^\\+0|^\\+{2,}"  // 00 prefix or ++ prefix (common spoofing)
    );

    // Suspicious call patterns from known fraud prefixes
    private static final List<String> SUSPICIOUS_PREFIXES = Arrays.asList(
        "+92",   // Pakistan - common in fraud calls to India
        "+880",  // Bangladesh
        "+251",  // Ethiopia
        "+234",  // Nigeria
        "+63",   // Philippines
        "00923", "00880"
    );

    private static final List<String> FRAUD_IVR_NUMBERS = Arrays.asList(
        "140", "141", "142",  // Telemarketing
        "1800", "1860"        // Some fraud IVR numbers
    );

    @Override
    public void onReceive(Context context, Intent intent) {
        if (!SharedPrefManager.isProtectionEnabled(context)) return;

        String state = intent.getStringExtra(TelephonyManager.EXTRA_STATE);
        String incomingNumber = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER);

        if (state == null) return;

        if (TelephonyManager.EXTRA_STATE_RINGING.equals(state) && incomingNumber != null) {
            analyzeIncomingCall(context, incomingNumber);
        }

        if (TelephonyManager.EXTRA_STATE_OFFHOOK.equals(state)) {
            // Call answered — show reminder about common fraud tactics
            showCallSecurityReminder(context);
        }
    }

    private void analyzeIncomingCall(Context context, String number) {
        String cleanNumber = number.replaceAll("[\\s\\-()]", "");
        String warningMessage = null;
        String warningTitle = null;
        boolean isCritical = false;

        // Check spoofed number patterns
        if (SPOOFED_NUMBER.matcher(cleanNumber).find()) {
            warningTitle = "⚠️ Possible Spoofed Call!";
            warningMessage = "This call may be from a SPOOFED number. Fraudsters fake official numbers to steal money.\n\nDo NOT share OTP, PIN, or any banking details!\n\nCaller: " + number;
            isCritical = true;
        }

        // Check suspicious international prefixes
        if (warningTitle == null) {
            for (String prefix : SUSPICIOUS_PREFIXES) {
                if (cleanNumber.startsWith(prefix)) {
                    warningTitle = "🌐 Suspicious International Call";
                    warningMessage = "Call from international number with suspicious prefix.\nMany banking frauds come from such numbers.\n\nDo NOT share any personal or financial info!\n\nNumber: " + number;
                    isCritical = false;
                    break;
                }
            }
        }

        // Check if number is very long (suspicious)
        if (warningTitle == null && cleanNumber.length() > 13) {
            warningTitle = "🔍 Unusual Number Length";
            warningMessage = "This number has unusual format which could indicate caller ID spoofing.\n\nBe careful if asked for OTP or banking details.\n\nNumber: " + number;
        }

        if (warningTitle != null) {
            SharedPrefManager.incrementAlertCount(context);
            NotificationHelper.showThreatNotification(context, warningTitle, warningMessage);
            ThreatLogger.log(context, warningTitle, "Call from: " + number);

            Intent alertIntent = new Intent(context, ThreatAlertActivity.class);
            alertIntent.putExtra("threat_title", warningTitle);
            alertIntent.putExtra("threat_message", warningMessage);
            alertIntent.putExtra("threat_level", isCritical ? "CRITICAL" : "HIGH");
            alertIntent.putExtra("threat_sender", number);
            alertIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            context.startActivity(alertIntent);
        }
    }

    private void showCallSecurityReminder(Context context) {
        // Show a quick notification reminder when call is answered
        NotificationHelper.showCallReminder(context,
            "🛡️ Stay Safe on This Call",
            "NEVER share: OTP • ATM PIN • Bank Password • CVV with anyone claiming to be bank/tech support"
        );
    }
}
