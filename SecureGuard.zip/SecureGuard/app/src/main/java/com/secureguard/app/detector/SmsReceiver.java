package com.secureguard.app.detector;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsMessage;
import android.util.Log;
import com.secureguard.app.ui.ThreatAlertActivity;
import com.secureguard.app.utils.NotificationHelper;
import com.secureguard.app.utils.SharedPrefManager;
import com.secureguard.app.utils.ThreatLogger;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SmsReceiver extends BroadcastReceiver {

    private static final String TAG = "SecureGuard_SMS";

    // OTP patterns
    private static final Pattern OTP_PATTERN = Pattern.compile(
        "\\b(OTP|otp|One.?Time.?Password|verification.?code|confirm.?code)\\b.*?(\\d{4,8})|" +
        "(\\d{4,8}).*?\\b(OTP|otp|One.?Time.?Password|verification.?code)\\b",
        Pattern.CASE_INSENSITIVE
    );

    // Fraud/Phishing keywords
    private static final List<String> FRAUD_KEYWORDS = Arrays.asList(
        "click here", "verify now", "account suspended", "urgent action",
        "won prize", "lottery", "click link", "verify your account",
        "blocked account", "kyc pending", "update kyc", "link expired",
        "congratulations you won", "claim reward", "free recharge",
        "bit.ly", "tinyurl", "t.co/", "goo.gl",  // Short URLs (common in phishing)
        "http://", "verify.link", "secure-login", "bank-update"
    );

    // UPI/Banking fraud patterns
    private static final List<String> BANKING_FRAUD_KEYWORDS = Arrays.asList(
        "upi pin", "share otp", "give otp", "tell otp", "send otp",
        "debit card number", "cvv", "net banking password",
        "atm pin", "account number", "ifsc", "upi id blocked",
        "paytm kyc", "phonepe kyc", "gpay kyc", "bhim kyc",
        "refund initiated send", "money credited share"
    );

    // Known fraud number patterns
    private static final Pattern SUSPICIOUS_NUMBER = Pattern.compile(
        "^\\+?[^+]{12,}$|^00\\d{10,}$"  // Very long numbers or 00 prefix
    );

    @Override
    public void onReceive(Context context, Intent intent) {
        if (!SharedPrefManager.isProtectionEnabled(context)) return;

        Bundle bundle = intent.getExtras();
        if (bundle == null) return;

        Object[] pdus = (Object[]) bundle.get("pdus");
        String format = bundle.getString("format");
        if (pdus == null) return;

        for (Object pdu : pdus) {
            SmsMessage smsMessage = SmsMessage.createFromPdu((byte[]) pdu, format);
            if (smsMessage == null) continue;

            String sender = smsMessage.getDisplayOriginatingAddress();
            String body = smsMessage.getMessageBody();

            if (body == null) continue;

            analyzeMessage(context, sender, body);
        }
    }

    private void analyzeMessage(Context context, String sender, String body) {
        String lowerBody = body.toLowerCase();
        ThreatInfo threat = null;

        // Check if OTP message and any app might intercept it
        if (containsOTP(body)) {
            // This is fine — OTP received. But log it to watch for re-reads
            Log.d(TAG, "OTP SMS detected from: " + sender);
            ThreatLogger.log(context, "OTP Received", "SMS from " + sender + " contains OTP");

            // Check if ALSO contains fraud elements
            if (containsBankingFraud(lowerBody)) {
                threat = new ThreatInfo(
                    "🚨 CRITICAL: OTP Fraud SMS!",
                    "Suspicious SMS asking you to SHARE OTP! Never share OTP with anyone.\n\nSender: " + sender,
                    ThreatLevel.CRITICAL,
                    sender
                );
            }
        }

        // Check for phishing links
        if (containsFraudLink(lowerBody)) {
            threat = new ThreatInfo(
                "⚠️ Fraud Link Detected!",
                "SMS contains a suspicious link. Do NOT click!\n\nSender: " + sender + "\n\nMessage: " + body.substring(0, Math.min(100, body.length())),
                ThreatLevel.HIGH,
                sender
            );
        }

        // Check for banking fraud keywords
        if (containsBankingFraud(lowerBody) && threat == null) {
            threat = new ThreatInfo(
                "⚠️ Banking Fraud Alert!",
                "SMS contains banking fraud keywords. Do NOT follow any instructions!\n\nSender: " + sender,
                ThreatLevel.HIGH,
                sender
            );
        }

        // General fraud keywords
        if (containsFraudKeywords(lowerBody) && threat == null) {
            threat = new ThreatInfo(
                "🔍 Suspicious SMS",
                "This SMS may be a scam. Be careful!\n\nSender: " + sender,
                ThreatLevel.MEDIUM,
                sender
            );
        }

        if (threat != null) {
            SharedPrefManager.incrementAlertCount(context);
            NotificationHelper.showThreatNotification(context, threat.title, threat.message);
            ThreatLogger.log(context, threat.title, "From: " + sender + " | " + threat.message);
            launchThreatAlert(context, threat);
        }
    }

    private boolean containsOTP(String body) {
        return OTP_PATTERN.matcher(body).find() ||
               body.matches(".*\\b\\d{4,8}\\b.*") && body.toLowerCase().contains("otp");
    }

    private boolean containsFraudLink(String body) {
        for (String keyword : Arrays.asList("http://", "bit.ly", "tinyurl", "t.co/", "goo.gl", "verify.link")) {
            if (body.contains(keyword)) return true;
        }
        return false;
    }

    private boolean containsBankingFraud(String body) {
        for (String keyword : BANKING_FRAUD_KEYWORDS) {
            if (body.contains(keyword)) return true;
        }
        return false;
    }

    private boolean containsFraudKeywords(String body) {
        for (String keyword : FRAUD_KEYWORDS) {
            if (body.contains(keyword)) return true;
        }
        return false;
    }

    private void launchThreatAlert(Context context, ThreatInfo threat) {
        Intent alertIntent = new Intent(context, ThreatAlertActivity.class);
        alertIntent.putExtra("threat_title", threat.title);
        alertIntent.putExtra("threat_message", threat.message);
        alertIntent.putExtra("threat_level", threat.level.name());
        alertIntent.putExtra("threat_sender", threat.sender);
        alertIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        context.startActivity(alertIntent);
    }

    // ---- Model ----
    public static class ThreatInfo {
        public final String title;
        public final String message;
        public final ThreatLevel level;
        public final String sender;

        public ThreatInfo(String title, String message, ThreatLevel level, String sender) {
            this.title = title;
            this.message = message;
            this.level = level;
            this.sender = sender;
        }
    }

    public enum ThreatLevel { MEDIUM, HIGH, CRITICAL }
}
