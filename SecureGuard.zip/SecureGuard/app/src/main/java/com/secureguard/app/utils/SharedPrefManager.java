package com.secureguard.app.utils;

import android.content.Context;
import android.content.SharedPreferences;

public class SharedPrefManager {
    private static final String PREF_NAME = "secureguard_prefs";
    private static final String KEY_PROTECTION = "protection_enabled";
    private static final String KEY_BLOCKED = "blocked_count";
    private static final String KEY_ALERTS = "alert_count";

    private static SharedPreferences getPrefs(Context context) {
        return context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }

    public static boolean isProtectionEnabled(Context context) {
        return getPrefs(context).getBoolean(KEY_PROTECTION, true);
    }

    public static void setProtectionEnabled(Context context, boolean enabled) {
        getPrefs(context).edit().putBoolean(KEY_PROTECTION, enabled).apply();
    }

    public static int getBlockedCount(Context context) {
        return getPrefs(context).getInt(KEY_BLOCKED, 0);
    }

    public static void incrementBlockedCount(Context context) {
        int current = getBlockedCount(context);
        getPrefs(context).edit().putInt(KEY_BLOCKED, current + 1).apply();
    }

    public static int getAlertCount(Context context) {
        return getPrefs(context).getInt(KEY_ALERTS, 0);
    }

    public static void incrementAlertCount(Context context) {
        int current = getAlertCount(context);
        getPrefs(context).edit().putInt(KEY_ALERTS, current + 1).apply();
    }
}
