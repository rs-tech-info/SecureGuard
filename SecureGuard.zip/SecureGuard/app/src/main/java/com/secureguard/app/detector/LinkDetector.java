package com.secureguard.app.detector;

import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class LinkDetector {

    // Known phishing domains / patterns
    private static final List<String> PHISHING_DOMAINS = Arrays.asList(
        "secure-bank-verify", "bank-update-kyc", "paytm-kyc-verify",
        "sbi-update", "hdfc-verify", "icici-secure", "axis-bank-login",
        "rbl-bank", "kotak-secure", "pnb-netbanking", "boi-online",
        "upi-verify", "bhim-upi-update", "gpay-verify", "phonepe-kyc",
        "login-verify-secure", "account-verify-update", "aadhaar-update-link",
        "pan-verify-online", "income-tax-refund-claim"
    );

    private static final List<String> URL_SHORTENERS = Arrays.asList(
        "bit.ly", "tinyurl.com", "t.co", "goo.gl", "ow.ly",
        "is.gd", "buff.ly", "adf.ly", "tiny.cc", "rb.gy",
        "cutt.ly", "shorturl.at", "short.io"
    );

    private static final List<String> SAFE_DOMAINS = Arrays.asList(
        "sbi.co.in", "hdfcbank.com", "icicibank.com", "axisbank.com",
        "paytm.com", "phonepe.com", "gpay.app", "upi.npci.org.in",
        "npci.org.in", "rbi.org.in", "incometax.gov.in",
        "google.com", "microsoft.com", "apple.com", "amazon.in",
        "flipkart.com", "youtube.com", "facebook.com", "instagram.com"
    );

    private static final Pattern URL_PATTERN = Pattern.compile(
        "https?://[\\w\\-._~:/?#\\[\\]@!$&'()*+,;=%]+"
    );

    public static LinkAnalysis analyzeUrl(String url) {
        if (url == null || url.isEmpty()) return new LinkAnalysis(RiskLevel.SAFE, "No URL");

        String lowerUrl = url.toLowerCase().trim();

        // Check if it's a known safe domain
        for (String safe : SAFE_DOMAINS) {
            if (lowerUrl.contains(safe)) {
                return new LinkAnalysis(RiskLevel.SAFE, "Trusted domain: " + safe);
            }
        }

        // Check URL shorteners (suspicious — hides real destination)
        for (String shortener : URL_SHORTENERS) {
            if (lowerUrl.contains(shortener)) {
                return new LinkAnalysis(RiskLevel.HIGH,
                    "⚠️ Short URL detected! Fraudsters hide malicious links in short URLs.\nDo NOT click: " + url);
            }
        }

        // Check known phishing patterns in URL
        for (String phishing : PHISHING_DOMAINS) {
            if (lowerUrl.contains(phishing)) {
                return new LinkAnalysis(RiskLevel.CRITICAL,
                    "🚨 PHISHING LINK! This URL is designed to steal your banking credentials.\nNEVER click: " + url);
            }
        }

        // Check for IP address URLs (suspicious — real banks never use IPs)
        if (lowerUrl.matches("https?://\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}.*")) {
            return new LinkAnalysis(RiskLevel.CRITICAL,
                "🚨 Dangerous! Link goes to an IP address. Banks NEVER send IP-based links.\nDo NOT open: " + url);
        }

        // Check for suspicious keywords in URL
        List<String> suspiciousUrlKeywords = Arrays.asList(
            "verify", "update", "secure", "login", "account", "bank",
            "kyc", "otp", "confirm", "suspend", "blocked", "unlock"
        );
        int suspiciousCount = 0;
        for (String keyword : suspiciousUrlKeywords) {
            if (lowerUrl.contains(keyword)) suspiciousCount++;
        }

        if (suspiciousCount >= 3) {
            return new LinkAnalysis(RiskLevel.HIGH,
                "⚠️ URL contains multiple suspicious keywords. Possible phishing site.\nBe careful: " + url);
        } else if (suspiciousCount >= 1) {
            return new LinkAnalysis(RiskLevel.MEDIUM,
                "🔍 URL contains suspicious keywords. Verify before clicking: " + url);
        }

        // HTTP (not HTTPS) links from messages
        if (lowerUrl.startsWith("http://")) {
            return new LinkAnalysis(RiskLevel.MEDIUM,
                "🔍 Unsecured HTTP link. Legitimate banks always use HTTPS.\nBe cautious: " + url);
        }

        return new LinkAnalysis(RiskLevel.SAFE, "Link appears safe: " + url);
    }

    public static List<String> extractUrls(String text) {
        List<String> urls = new java.util.ArrayList<>();
        if (text == null) return urls;
        Matcher matcher = URL_PATTERN.matcher(text);
        while (matcher.find()) {
            urls.add(matcher.group());
        }
        return urls;
    }

    public static class LinkAnalysis {
        public final RiskLevel riskLevel;
        public final String message;

        public LinkAnalysis(RiskLevel riskLevel, String message) {
            this.riskLevel = riskLevel;
            this.message = message;
        }
    }

    public enum RiskLevel { SAFE, MEDIUM, HIGH, CRITICAL }
}
