package com.secureguard.app.ui;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.secureguard.app.databinding.ActivityMainBinding;
import com.secureguard.app.detector.AppScanner;
import com.secureguard.app.service.SecurityService;
import com.secureguard.app.utils.ThreatDatabase;
import com.secureguard.app.utils.SharedPrefManager;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;
    private AppScanner appScanner;
    private ThreatDatabase threatDatabase;
    private RiskyAppAdapter riskyAppAdapter;
    private static final int PERMISSION_REQUEST_CODE = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        appScanner = new AppScanner(this);
        threatDatabase = new ThreatDatabase(this);

        setupDashboard();
        requestRequiredPermissions();
        startSecurityService();
        loadScannedApps();
        updateDashboardStats();
    }

    private void setupDashboard() {
        // Setup RecyclerView for risky apps
        riskyAppAdapter = new RiskyAppAdapter(this, app -> {
            Intent intent = new Intent(this, AppDetailActivity.class);
            intent.putExtra("package_name", app.getPackageName());
            startActivity(intent);
        });
        binding.rvRiskyApps.setLayoutManager(new LinearLayoutManager(this));
        binding.rvRiskyApps.setAdapter(riskyAppAdapter);

        // Scan button
        binding.btnScanNow.setOnClickListener(v -> performFullScan());

        // Shield status toggle
        binding.switchProtection.setOnCheckedChangeListener((btn, checked) -> {
            SharedPrefManager.setProtectionEnabled(this, checked);
            updateShieldStatus(checked);
        });
        boolean isEnabled = SharedPrefManager.isProtectionEnabled(this);
        binding.switchProtection.setChecked(isEnabled);
        updateShieldStatus(isEnabled);

        // Accessibility service button
        binding.btnAccessibility.setOnClickListener(v -> openAccessibilitySettings());

        // Notification permission button
        binding.btnNotifAccess.setOnClickListener(v -> openNotificationAccess());
    }

    private void performFullScan() {
        binding.btnScanNow.setEnabled(false);
        binding.btnScanNow.setText("Scanning...");
        binding.progressScan.setVisibility(View.VISIBLE);

        new Thread(() -> {
            List<AppScanner.ScannedApp> riskyApps = appScanner.scanAllApps();
            runOnUiThread(() -> {
                riskyAppAdapter.updateData(riskyApps);
                binding.tvThreatCount.setText(String.valueOf(riskyApps.size()));
                binding.btnScanNow.setEnabled(true);
                binding.btnScanNow.setText("Scan Now");
                binding.progressScan.setVisibility(View.GONE);

                if (riskyApps.isEmpty()) {
                    binding.tvScanStatus.setText("✅ Phone is Safe!");
                    binding.tvScanStatus.setTextColor(getColor(android.R.color.holo_green_dark));
                } else {
                    binding.tvScanStatus.setText("⚠️ " + riskyApps.size() + " Threats Found!");
                    binding.tvScanStatus.setTextColor(getColor(android.R.color.holo_red_dark));
                }

                Toast.makeText(this, "Scan Complete! " + riskyApps.size() + " risky apps found.", Toast.LENGTH_SHORT).show();
            });
        }).start();
    }

    private void loadScannedApps() {
        new Thread(() -> {
            List<AppScanner.ScannedApp> riskyApps = appScanner.scanAllApps();
            runOnUiThread(() -> {
                riskyAppAdapter.updateData(riskyApps);
                binding.tvThreatCount.setText(String.valueOf(riskyApps.size()));
                if (!riskyApps.isEmpty()) {
                    binding.tvScanStatus.setText("⚠️ " + riskyApps.size() + " Risky Apps Found!");
                    binding.tvScanStatus.setTextColor(getColor(android.R.color.holo_red_dark));
                }
            });
        }).start();
    }

    private void updateDashboardStats() {
        int blockedCount = SharedPrefManager.getBlockedCount(this);
        int alertCount = SharedPrefManager.getAlertCount(this);
        binding.tvBlockedCount.setText(String.valueOf(blockedCount));
        binding.tvAlertCount.setText(String.valueOf(alertCount));
    }

    private void updateShieldStatus(boolean enabled) {
        if (enabled) {
            binding.ivShieldStatus.setImageResource(android.R.drawable.ic_lock_lock);
            binding.tvProtectionStatus.setText("Protection: ACTIVE");
            binding.tvProtectionStatus.setTextColor(getColor(android.R.color.holo_green_dark));
            binding.cardShield.setCardBackgroundColor(getColor(android.R.color.holo_green_light));
        } else {
            binding.ivShieldStatus.setImageResource(android.R.drawable.ic_lock_idle_lock);
            binding.tvProtectionStatus.setText("Protection: DISABLED");
            binding.tvProtectionStatus.setTextColor(getColor(android.R.color.holo_red_dark));
            binding.cardShield.setCardBackgroundColor(getColor(android.R.color.holo_red_light));
        }
    }

    private void startSecurityService() {
        Intent serviceIntent = new Intent(this, SecurityService.class);
        ContextCompat.startForegroundService(this, serviceIntent);
    }

    private void openAccessibilitySettings() {
        new AlertDialog.Builder(this)
            .setTitle("Enable Accessibility")
            .setMessage("SecureGuard needs Accessibility Service to detect malicious apps reading your OTP and banking data.\n\nGo to Settings → Accessibility → SecureGuard → Enable")
            .setPositiveButton("Open Settings", (d, w) -> {
                Intent intent = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
                startActivity(intent);
            })
            .setNegativeButton("Cancel", null)
            .show();
    }

    private void openNotificationAccess() {
        new AlertDialog.Builder(this)
            .setTitle("Notification Access")
            .setMessage("Allow SecureGuard to monitor notifications to detect fraud alerts and OTP interception attempts.")
            .setPositiveButton("Open Settings", (d, w) -> {
                Intent intent = new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS);
                startActivity(intent);
            })
            .setNegativeButton("Cancel", null)
            .show();
    }

    private void requestRequiredPermissions() {
        String[] permissions = {
            Manifest.permission.READ_SMS,
            Manifest.permission.RECEIVE_SMS,
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.READ_CALL_LOG,
            Manifest.permission.POST_NOTIFICATIONS
        };

        boolean allGranted = true;
        for (String perm : permissions) {
            if (ContextCompat.checkSelfPermission(this, perm) != PackageManager.PERMISSION_GRANTED) {
                allGranted = false;
                break;
            }
        }

        if (!allGranted) {
            ActivityCompat.requestPermissions(this, permissions, PERMISSION_REQUEST_CODE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            boolean allGranted = true;
            for (int result : results) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    allGranted = false;
                    break;
                }
            }
            if (!allGranted) {
                Toast.makeText(this, "Some permissions denied. App may not work fully.", Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateDashboardStats();
    }
}
