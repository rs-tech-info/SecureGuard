package com.secureguard.app.service;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.pm.PackageManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import com.secureguard.app.utils.NotificationHelper;
import com.secureguard.app.utils.SharedPrefManager;
import com.secureguard.app.utils.ThreatLogger;
import java.util.Arrays;
import java.util.List;

public class SecureAccessibilityService extends AccessibilityService {

    // Apps that should NEVER be reading OTP/SMS content
    private static final List<String> SUSPICIOUS_SMS_READERS = Arrays.asList(
        "com.truecaller", // Not suspicious but as example
        "com.screen.share",
        "anydesk.com.anydesk",
        "com.teamviewer.host"
    );

    // Keywords that indicate OTP/financial data is being displayed
    private static final List<String> OTP_KEYWORDS = Arrays.asList(
        "otp", "one time password", "verification code", "confirm code",
        "cvv", "atm pin", "net banking", "upi pin", "mpin"
    );

    private String lastActivePackage = "";

    @Override
    protected void onServiceConnected() {
        AccessibilityServiceInfo info = new AccessibilityServiceInfo();
        info.eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED |
                         AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED;
        info.feedbackType = AccessibilityServiceInfo.FEEDBACK_ALL_MASK;
        info.flags = AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS |
                    AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS;
        info.notificationTimeout = 100;
        setServiceInfo(info);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (!SharedPrefManager.isProtectionEnabled(this)) return;

        String packageName = event.getPackageName() != null ?
            event.getPackageName().toString() : "";

        // Skip our own app
        if (packageName.equals("com.secureguard.app")) return;

        // Detect screen sharing apps becoming active
        if (isScreenSharingApp(packageName) && !packageName.equals(lastActivePackage)) {
            String appName = getAppName(packageName);
            NotificationHelper.showThreatNotification(this,
                "🚨 Screen Sharing App Active!",
                appName + " can SEE your screen including OTPs and banking info. Be very careful!");
            ThreatLogger.log(this, "Screen Sharing Detected", "App: " + packageName + " is active");
        }

        lastActivePackage = packageName;

        // Scan window content for sensitive data being displayed
        if (event.getEventType() == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) {
            AccessibilityNodeInfo rootNode = getRootInActiveWindow();
            if (rootNode != null) {
                String windowContent = extractText(rootNode);
                analyzeWindowContent(packageName, windowContent);
                rootNode.recycle();
            }
        }
    }

    private void analyzeWindowContent(String packageName, String content) {
        if (content == null || content.isEmpty()) return;
        String lowerContent = content.toLowerCase();

        boolean hasOtpContent = false;
        for (String keyword : OTP_KEYWORDS) {
            if (lowerContent.contains(keyword)) {
                hasOtpContent = true;
                break;
            }
        }

        // If a suspicious app is displaying OTP-related content
        if (hasOtpContent && isScreenSharingApp(packageName)) {
            NotificationHelper.showThreatNotification(this,
                "🚨 OTP Data Exposed!",
                "A screen sharing app may be reading your OTP/banking info! Close it immediately!");
            ThreatLogger.log(this, "OTP Exposure Risk",
                "Package: " + packageName + " is viewing OTP-related content");
        }
    }

    private String extractText(AccessibilityNodeInfo node) {
        if (node == null) return "";
        StringBuilder sb = new StringBuilder();
        if (node.getText() != null) sb.append(node.getText()).append(" ");
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                sb.append(extractText(child));
                child.recycle();
            }
        }
        return sb.toString();
    }

    private boolean isScreenSharingApp(String packageName) {
        String lower = packageName.toLowerCase();
        return lower.contains("screen") || lower.contains("remote") ||
               lower.contains("anydesk") || lower.contains("teamviewer") ||
               lower.contains("vnc") || lower.contains("rdp") ||
               SUSPICIOUS_SMS_READERS.contains(packageName);
    }

    private String getAppName(String packageName) {
        try {
            PackageManager pm = getPackageManager();
            return pm.getApplicationLabel(pm.getApplicationInfo(packageName, 0)).toString();
        } catch (Exception e) {
            return packageName;
        }
    }

    @Override
    public void onInterrupt() {}
}
