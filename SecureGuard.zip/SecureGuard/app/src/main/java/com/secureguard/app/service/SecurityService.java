package com.secureguard.app.service;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import androidx.core.app.NotificationCompat;
import com.secureguard.app.R;
import com.secureguard.app.detector.AppScanner;
import com.secureguard.app.ui.MainActivity;
import com.secureguard.app.utils.SharedPrefManager;
import java.util.List;

public class SecurityService extends Service {

    private static final String CHANNEL_ID = "secureguard_protection";
    private static final int NOTIFICATION_ID = 1001;
    private static final long SCAN_INTERVAL = 30 * 60 * 1000; // 30 minutes

    private Handler handler;
    private AppScanner appScanner;

    private final Runnable periodicScanRunnable = new Runnable() {
        @Override
        public void run() {
            performBackgroundScan();
            handler.postDelayed(this, SCAN_INTERVAL);
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        handler = new Handler(Looper.getMainLooper());
        appScanner = new AppScanner(this);
        createNotificationChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        startForeground(NOTIFICATION_ID, buildNotification("🛡️ Protecting your phone...", "SecureGuard is active"));
        handler.post(periodicScanRunnable);
        return START_STICKY; // Restart if killed
    }

    private void performBackgroundScan() {
        if (!SharedPrefManager.isProtectionEnabled(this)) return;

        new Thread(() -> {
            List<AppScanner.ScannedApp> riskyApps = appScanner.scanAllApps();
            long criticalCount = riskyApps.stream()
                .filter(a -> a.getRiskLevel() == AppScanner.RiskLevel.CRITICAL)
                .count();

            if (criticalCount > 0) {
                updateNotification("🚨 " + criticalCount + " Critical Threats Found!",
                    "Tap to see dangerous apps on your phone");
            } else if (!riskyApps.isEmpty()) {
                updateNotification("⚠️ " + riskyApps.size() + " Suspicious Apps",
                    "Tap to review risky apps");
            } else {
                updateNotification("✅ Phone is Safe", "No threats detected");
            }
        }).start();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID, "SecureGuard Protection", NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Background protection service");
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }

    private Notification buildNotification(String title, String message) {
        Intent mainIntent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(
            this, 0, mainIntent, PendingIntent.FLAG_IMMUTABLE
        );

        return new NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(message)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build();
    }

    private void updateNotification(String title, String message) {
        NotificationManager manager = getSystemService(NotificationManager.class);
        if (manager != null) {
            manager.notify(NOTIFICATION_ID, buildNotification(title, message));
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        handler.removeCallbacks(periodicScanRunnable);
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
