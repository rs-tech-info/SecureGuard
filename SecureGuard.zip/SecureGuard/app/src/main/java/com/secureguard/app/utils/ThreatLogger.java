package com.secureguard.app.utils;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class ThreatLogger {
    private static final String PREF_NAME = "secureguard_logs";
    private static final String KEY_LOGS = "threat_logs";
    private static final int MAX_LOGS = 100;

    public static void log(Context context, String type, String detail) {
        try {
            SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
            String existing = prefs.getString(KEY_LOGS, "[]");
            JSONArray logs = new JSONArray(existing);

            JSONObject entry = new JSONObject();
            entry.put("type", type);
            entry.put("detail", detail);
            entry.put("time", new SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault()).format(new Date()));

            // Add to front
            JSONArray newLogs = new JSONArray();
            newLogs.put(entry);
            for (int i = 0; i < Math.min(logs.length(), MAX_LOGS - 1); i++) {
                newLogs.put(logs.get(i));
            }

            prefs.edit().putString(KEY_LOGS, newLogs.toString()).apply();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static JSONArray getLogs(Context context) {
        try {
            SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
            return new JSONArray(prefs.getString(KEY_LOGS, "[]"));
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    public static void clearLogs(Context context) {
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .edit().remove(KEY_LOGS).apply();
    }
}
