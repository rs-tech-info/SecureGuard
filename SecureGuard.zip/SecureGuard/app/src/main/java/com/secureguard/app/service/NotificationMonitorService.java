package com.secureguard.app.service;

import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import com.secureguard.app.detector.LinkDetector;
import com.secureguard.app.utils.NotificationHelper;
import com.secureguard.app.utils.SharedPrefManager;
import com.secureguard.app.utils.ThreatLogger;
import java.util.Arrays;
import java.util.List;

public class NotificationMonitorService extends NotificationListenerService {

    private static final List<String> FRAUD_NOTIFICATION_KEYWORDS = Arrays.asList(
        "otp", "your otp is", "verification code", "one time",
        "click here", "verify now", "account blocked", "suspicious activity",
        "urgent", "immediately", "your account", "login attempt",
        "transaction failed", "unusual activity", "security alert"
    );

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        if (!SharedPrefManager.isProtectionEnabled(this)) return;
        if (sbn == null || sbn.getPackageName().equals("com.secureguard.app")) return;

        android.os.Bundle extras = sbn.getNotification().extras;
        if (extras == null) return;

        CharSequence title = extras.getCharSequence("android.title");
        CharSequence text = extras.getCharSequence("android.text");

        String fullText = "";
        if (title != null) fullText += title.toString().toLowerCase() + " ";
        if (text != null) fullText += text.toString().toLowerCase();

        if (fullText.isEmpty()) return;

        // Check for OTP in notification from non-banking apps
        checkForOtpExposure(sbn.getPackageName(), fullText, title, text);

        // Check for fraud URLs in notification
        List<String> urls = LinkDetector.extractUrls(fullText);
        for (String url : urls) {
            LinkDetector.LinkAnalysis analysis = LinkDetector.analyzeUrl(url);
            if (analysis.riskLevel == LinkDetector.RiskLevel.HIGH ||
                analysis.riskLevel == LinkDetector.RiskLevel.CRITICAL) {
                NotificationHelper.showThreatNotification(this,
                    "🚨 Fraud Link in Notification!",
                    "App: " + getAppName(sbn.getPackageName()) + " sent a suspicious link.\n" + analysis.message);
                ThreatLogger.log(this, "Fraud URL in Notification",
                    "App: " + sbn.getPackageName() + " | URL: " + url);
                SharedPrefManager.incrementAlertCount(this);
            }
        }
    }

    private void checkForOtpExposure(String packageName, String content,
                                      CharSequence title, CharSequence text) {
        boolean hasOtp = content.contains("otp") ||
                        content.contains("one time") ||
                        content.contains("verification code");

        // OTP in notification from unknown/suspicious app
        if (hasOtp && isNotBankingApp(packageName)) {
            String appName = getAppName(packageName);
            NotificationHelper.showThreatNotification(this,
                "⚠️ OTP Exposed in Notification",
                appName + " is showing OTP data. Make sure this is a trusted app!");
            ThreatLogger.log(this, "OTP in Notification", "App: " + packageName + " showed OTP content");
        }
    }

    private boolean isNotBankingApp(String packageName) {
        List<String> KNOWN_BANKING_APPS = Arrays.asList(
            "com.sbi", "com.hdfc", "com.icici", "com.axis", "com.kotak",
            "com.paytm", "com.phonepe", "net.one97", "com.google.android.apps.nbu",
            "in.org.npci.upiapp", "com.mobikwik_new", "com.amazon.mshop"
        );

        for (String banking : KNOWN_BANKING_APPS) {
            if (packageName.startsWith(banking)) return false;
        }
        return true;
    }

    private String getAppName(String packageName) {
        try {
            return getPackageManager().getApplicationLabel(
                getPackageManager().getApplicationInfo(packageName, 0)
            ).toString();
        } catch (Exception e) {
            return packageName;
        }
    }
}
