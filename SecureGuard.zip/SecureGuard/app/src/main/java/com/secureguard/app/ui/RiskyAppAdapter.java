package com.secureguard.app.ui;

import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.secureguard.app.R;
import com.secureguard.app.detector.AppScanner;
import java.util.ArrayList;
import java.util.List;

public class RiskyAppAdapter extends RecyclerView.Adapter<RiskyAppAdapter.ViewHolder> {

    private final Context context;
    private List<AppScanner.ScannedApp> data = new ArrayList<>();
    private final OnAppClickListener listener;

    public interface OnAppClickListener {
        void onAppClick(AppScanner.ScannedApp app);
    }

    public RiskyAppAdapter(Context context, OnAppClickListener listener) {
        this.context = context;
        this.listener = listener;
    }

    public void updateData(List<AppScanner.ScannedApp> newData) {
        this.data = newData;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_risky_app, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        AppScanner.ScannedApp app = data.get(position);

        holder.tvAppName.setText(app.getAppName());
        holder.tvThreatType.setText(app.getThreatType());

        // Show permissions summary
        List<String> perms = app.getRiskyPermissions();
        if (!perms.isEmpty()) {
            String permSummary = String.join(", ", perms.subList(0, Math.min(2, perms.size())));
            if (perms.size() > 2) permSummary += " +" + (perms.size() - 2) + " more";
            holder.tvPermissions.setText(permSummary);
        } else {
            holder.tvPermissions.setText(app.isSideloaded() ? "Sideloaded app" : "Hidden app");
        }

        // Set badge color based on risk
        switch (app.getRiskLevel()) {
            case CRITICAL:
                holder.tvRiskBadge.setText("CRITICAL");
                holder.tvRiskBadge.setBackgroundColor(Color.parseColor("#D32F2F"));
                break;
            case HIGH:
                holder.tvRiskBadge.setText("HIGH");
                holder.tvRiskBadge.setBackgroundColor(Color.parseColor("#E65100"));
                break;
            case MEDIUM:
                holder.tvRiskBadge.setText("MEDIUM");
                holder.tvRiskBadge.setBackgroundColor(Color.parseColor("#F57F17"));
                break;
            default:
                holder.tvRiskBadge.setText("LOW");
                holder.tvRiskBadge.setBackgroundColor(Color.parseColor("#388E3C"));
        }

        // Load app icon
        try {
            holder.ivAppIcon.setImageDrawable(
                context.getPackageManager().getApplicationIcon(app.getPackageName())
            );
        } catch (PackageManager.NameNotFoundException e) {
            holder.ivAppIcon.setImageResource(android.R.drawable.sym_def_app_icon);
        }

        holder.itemView.setOnClickListener(v -> listener.onAppClick(app));
    }

    @Override
    public int getItemCount() { return data.size(); }

    static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView ivAppIcon;
        TextView tvAppName, tvThreatType, tvPermissions, tvRiskBadge;

        ViewHolder(View view) {
            super(view);
            ivAppIcon = view.findViewById(R.id.ivAppIcon);
            tvAppName = view.findViewById(R.id.tvAppName);
            tvThreatType = view.findViewById(R.id.tvThreatType);
            tvPermissions = view.findViewById(R.id.tvPermissions);
            tvRiskBadge = view.findViewById(R.id.tvRiskBadge);
        }
    }
}
