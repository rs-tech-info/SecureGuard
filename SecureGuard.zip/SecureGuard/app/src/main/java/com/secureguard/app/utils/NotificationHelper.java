package com.secureguard.app.utils;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import com.secureguard.app.ui.MainActivity;

public class NotificationHelper {

    private static final String THREAT_CHANNEL_ID = "secureguard_threats";
    private static final String CALL_CHANNEL_ID = "secureguard_calls";
    private static int notifId = 2000;

    public static void showThreatNotification(Context context, String title, String message) {
        createChannels(context);

        Intent intent = new Intent(context, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(
            context, 0, intent, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT
        );

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, THREAT_CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(new NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .setVibrate(new long[]{0, 500, 200, 500});

        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager != null) {
            manager.notify(notifId++, builder.build());
        }
    }

    public static void showCallReminder(Context context, String title, String message) {
        createChannels(context);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CALL_CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(new NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true);

        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager != null) {
            manager.notify(notifId++, builder.build());
        }
    }

    private static void createChannels(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager manager = (NotificationManager)
                context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (manager == null) return;

            NotificationChannel threatChannel = new NotificationChannel(
                THREAT_CHANNEL_ID, "Threat Alerts", NotificationManager.IMPORTANCE_HIGH
            );
            threatChannel.setDescription("Fraud and security threat alerts");
            threatChannel.enableVibration(true);

            NotificationChannel callChannel = new NotificationChannel(
                CALL_CHANNEL_ID, "Call Security", NotificationManager.IMPORTANCE_HIGH
            );
            callChannel.setDescription("Call security reminders");

            manager.createNotificationChannel(threatChannel);
            manager.createNotificationChannel(callChannel);
        }
    }
}
