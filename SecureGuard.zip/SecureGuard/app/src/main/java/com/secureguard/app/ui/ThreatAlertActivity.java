package com.secureguard.app.ui;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Vibrator;
import android.view.WindowManager;
import androidx.appcompat.app.AppCompatActivity;
import com.secureguard.app.databinding.ActivityThreatAlertBinding;

public class ThreatAlertActivity extends AppCompatActivity {

    private ActivityThreatAlertBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityThreatAlertBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Show over lock screen
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED |
                            WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON |
                            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        String threatTitle = getIntent().getStringExtra("threat_title");
        String threatMessage = getIntent().getStringExtra("threat_message");
        String threatLevel = getIntent().getStringExtra("threat_level");
        String sender = getIntent().getStringExtra("threat_sender");

        binding.tvThreatTitle.setText(threatTitle != null ? threatTitle : "⚠️ Threat Detected");
        binding.tvThreatMessage.setText(threatMessage != null ? threatMessage : "Suspicious activity detected");

        // Set background color based on threat level
        if ("CRITICAL".equals(threatLevel)) {
            binding.cardAlert.setCardBackgroundColor(getColor(android.R.color.holo_red_dark));
            vibratePhone(1000);
        } else if ("HIGH".equals(threatLevel)) {
            binding.cardAlert.setCardBackgroundColor(getColor(android.R.color.holo_orange_dark));
            vibratePhone(500);
        } else {
            binding.cardAlert.setCardBackgroundColor(getColor(android.R.color.holo_orange_light));
            vibratePhone(200);
        }

        // Block call button (if from call)
        if (sender != null && sender.matches("\\+?\\d{10,}")) {
            binding.btnBlockCaller.setVisibility(android.view.View.VISIBLE);
            binding.btnBlockCaller.setOnClickListener(v -> {
                Intent intent = new Intent(Intent.ACTION_VIEW,
                    Uri.parse("content://call_log/calls"));
                startActivity(intent);
            });
        }

        // Report fraud
        binding.btnReportFraud.setOnClickListener(v -> {
            // Open National Cyber Crime portal
            Intent intent = new Intent(Intent.ACTION_VIEW,
                Uri.parse("https://cybercrime.gov.in"));
            startActivity(intent);
        });

        // Dismiss button
        binding.btnDismiss.setOnClickListener(v -> finish());

        // Report to 1930 (Cyber Crime Helpline India)
        binding.btnCallCyberCrime.setOnClickListener(v -> {
            Intent callIntent = new Intent(Intent.ACTION_DIAL,
                Uri.parse("tel:1930"));
            startActivity(callIntent);
        });
    }

    private void vibratePhone(int duration) {
        Vibrator vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
        if (vibrator != null && vibrator.hasVibrator()) {
            vibrator.vibrate(duration);
        }
    }
}
